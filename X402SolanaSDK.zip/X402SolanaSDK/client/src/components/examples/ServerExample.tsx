import { ServerExample } from '../ServerExample';

export default function ServerExampleExample() {
  return <ServerExample />;
}
