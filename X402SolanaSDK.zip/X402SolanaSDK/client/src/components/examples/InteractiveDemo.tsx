import { InteractiveDemo } from '../InteractiveDemo';

export default function InteractiveDemoExample() {
  return <InteractiveDemo />;
}
