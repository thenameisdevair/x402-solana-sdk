import { QuickStart } from '../QuickStart';

export default function QuickStartExample() {
  return <QuickStart />;
}
